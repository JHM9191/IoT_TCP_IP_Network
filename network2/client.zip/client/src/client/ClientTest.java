package client;

public class ClientTest {
	public static void main(String[] args) {
//		Client client = new Client("192.168.43.1", 8888, "IoT_Client_1");
//		Client client = new Client("192.168.43.180", 8888, "IoT_Client_1");
//		Client client = new Client("192.168.43.53", 9999, "IoT_Client_1"); // hotspot tabserver ip
		Client client = new Client("70.12.225.91", 9999, "IoT_Client_1"); // MULTI_GUEST tabserver ip
//		Client client = new  Client("70.12.230.140", 8888, "JHM");
	}
	
}
